// gcc sleepingTA.c -lpthread -o sleepingTA
// ./sleepingTA

#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>

#define MAX_CHAIRS_NUM 10 //實驗室外可坐椅子的最大數量

//- global param defination ------------------//
int studentPerTime[100];				   // 每個單位時間點是否有學生來的情況 0：沒有學生來 1:有學生來
int numOfOccupiedChairs = 0;		   // 被佔據椅子初始值
int waitingTime = 0, waitingStudents = 0; // 總等待時間，等待的學生數

//設定旗標semaphore ={可不可以坐椅子（椅子鎖）， 時間mutex，學生的sem，TA的sem}
sem_t chairMutex,timeMutex, availableStudentsSem, TA_sem;

// 時間的flag
int timeFlag = 0;
int allStudent = 0;

//- function prototype -----------------------//
void *TA(void *temp);
void *Student(void *temp);

int main(void)
{
	//- thread defination --------------------//
	pthread_t TA_id;
	pthread_t student_ids[100]; //可能有100個student來

	//- read input.txt -----------------------//
	FILE *f;
	//FILE * fopen ( const char * filename, const char * mode )
	//"r" : 開啟檔案，供程式讀取文字內容
	f = fopen("input.txt", "r");

	for (int i = 0; i < 100; i++)
	{
		int temp;
		// &temp為返回值
		// %d 代表 十進位數
		fscanf(f, "%d\n", &temp);
		studentPerTime[i] = temp;
	}
	fclose(f);

	//- initialize semaphores ----------------//
	// 初始化旗標semaphore
	// 第二個參數是指定是否要讓其他的行程（process）共用旗標
	// 第三個參數則是設定旗標的初始值。
    // sem > 0
	sem_init(&chairMutex, 0, 1); // 鎖，範圍：0-1
	sem_init(&timeMutex, 0, 1);   // 時間鎖，最多1
	sem_init(&availableStudentsSem, 0, 0);   //student數量 0-n
	sem_init(&TA_sem, 0,  0);   //TA sem 0-1

	//- create TA thread -----------------//
	pthread_create(&TA_id, NULL, TA, NULL);

	//- create Student thread -----------------//
	//建立Student thread
	for (int i = 0; i < 100; i++)
	{
		if (studentPerTime[i] != 0)
		{
			allStudent++;
			// (id's pointer, thread之屬性, 處理函數之pointer, 帶入函數之參數)
			pthread_create(&student_ids[i], NULL, Student, NULL);
		}
		//近來一次為一個單位時間
		sleep(1);
	}

	printf("Total waiting time = %d\n\n", waitingTime);
	double avgwaitingTime;
	//計算平均等待時間
	avgwaitingTime = (double)waitingTime / waitingStudents;
	printf("Avg waiting Time %lf\n", avgwaitingTime);
	printf("came studets number %d\n", allStudent);

	return 0;
}

void *TA(void *temp)
{
	while (1)
	{
		sem_wait(&availableStudentsSem);    //等待是否有坐在實驗室外椅子上的學生
		sem_wait(&chairMutex); 

		//...code	
		//TA讓學生離開椅子
 
		sem_post(&TA_sem);   // TA available
		sem_post(&chairMutex);  //此時已學生離開椅子，進實驗室

		//...code	
        //開始幫忙學生。提示：調用usleep()。
	}
}

void *Student(void *temp)
{
	sem_wait(&chairMutex); 

	if (numOfOccupiedChairs < MAX_CHAIRS_NUM) //檢查實驗室外是否還有多的椅子可以坐
	{
		//...code	
		//教室外有位子，學生佔據椅子

		sem_post(&availableStudentsSem);   // 等待學生加一
		sem_post(&chairMutex); 
		sem_wait(&TA_sem);   // 看TA是否有再忙
 
		//...code	
		//開始接受助教幫忙(更動時間)。
		//提示：可調用waitingTime，timeMutex，usleep()與numOfOccupiedChairs等等。
	}
	else
	{
		sem_post(&chairMutex); // 教室外沒有位子，學生離開
	}
}
